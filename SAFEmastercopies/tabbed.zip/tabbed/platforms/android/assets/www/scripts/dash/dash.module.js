(function() {
	'use strict';

	angular
		.module('app.dash', [
			'ionic'
		]);
})();