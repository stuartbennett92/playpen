(function() {
	'use strict';

	angular
		.module('app.chat', [
			'ionic'
		]);
})();