(function() {
	'use strict';

	angular
		.module('app.account', [
			'ionic'
		]);
})();